package main

import "./iso"

func main() {
	iso.IterateOverExtendedASCIIStringLiteral(iso.ASCIIExtended)
	iso.GreetingExtendedASCII()
}
