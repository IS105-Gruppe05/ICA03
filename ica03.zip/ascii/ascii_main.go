package main

import "./ascii"

func main() {
	ascii.IterateOverASCIIStringLiteral(ascii.ASCII)
	ascii.GreetingASCII()
}
